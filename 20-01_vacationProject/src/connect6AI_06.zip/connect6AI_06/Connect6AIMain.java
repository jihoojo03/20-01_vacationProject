package connect6AI_06;


public class Connect6AIMain {

	public static final int SCREEN_WIDTH = 960;
	public static final int SCREEN_HEIGHT = 640;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new GUITest();
	}

}
