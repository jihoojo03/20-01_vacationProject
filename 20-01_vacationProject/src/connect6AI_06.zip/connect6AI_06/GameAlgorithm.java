package connect6AI_06;

public class GameAlgorithm {
	private int amount;			// �� ������
	private int currentTurn;	// 0 : ��, 1 : ��
	private int stone[][];		// -1 : default, 0 : ��, 1 : ��, 2 : �߸���, 99 : ��
	private int nextStone[][];	// -1 : default, 0 : ��, 1 : ��, 2 : �߸���, 99 : ��
	private boolean isFirst;
	
	double[][] all1 = new double[21][21];
	double[][] hor1 = new double[21][21];
	double[][] ver1 = new double[21][21];
	double[][] left1 = new double[21][21];
	double[][] right1 = new double[21][21];
	
	double[][] all2 = new double[21][21];
	double[][] hor2 = new double[21][21];
	double[][] ver2 = new double[21][21];
	double[][] left2 = new double[21][21];
	double[][] right2 = new double[21][21];
	
	int nextX;
	int nextY;
	
	GameAlgorithm(){
		amount = 0;
		currentTurn = 0;
		isFirst = true;
		
		stone = new int[21][21];
		for(int i = 0; i < 21; i++) {
			for(int j = 0; j < 21; j++) {
				stone[i][j] = -1;
			}
		}
		for(int i = 0; i < 21; i++) {
			stone[i][0] = 99;
			stone[0][i] = 99;
			stone[i][20] = 99;
			stone[20][i] = 99;
		}
		
		nextStone = new int[21][21];
		for(int i = 0; i < 21; i++) {
			for(int j = 0; j < 21; j++) {
				nextStone[i][j] = -1;
			}
		}
		for(int i = 0; i < 21; i++) {
			nextStone[i][0] = 99;
			nextStone[0][i] = 99;
			nextStone[i][20] = 99;
			nextStone[20][i] = 99;
		}
	}
	
	public int getNextX() {
		return nextX;
	}

	public void setNextX(int nextX) {
		this.nextX = nextX;
	}

	public int getNextY() {
		return nextY;
	}

	public void setNextY(int nextY) {
		this.nextY = nextY;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getCurrentTurn() {
		return currentTurn;
	}

	public void setCurrentTurn(int currentTurn) {
		this.currentTurn = currentTurn;
	}

	public int[][] getStone() {
		return stone;
	}
	
	public void setStone(int x, int y, int stone) {
		this.stone[x][y] = stone;
	}
	
	public boolean isStone(int x, int y) {
		if(this.stone[x][y] == -1) return false;
		else return true;
	}
	
	public boolean isFirst() {
		return isFirst;
	}

	public void setFirst(boolean isFirst) {
		this.isFirst = isFirst;
	}

	public void launch() {
		amount++;
		if(amount % 4 == 0 || amount % 4 == 1) {
			currentTurn = 0;
		}
		else if(amount % 4 == 2 || amount % 4 == 3) {
			currentTurn = 1;
		}
	}

	public int win(int x, int y) {
		int highWin = 1;
		
		if(stone[x - 1][y] == currentTurn) {		// 1��
			if(stone[x + 1][y] == currentTurn) {
				highWin = winCount(x - 1, y, 1) + winCount(x + 1, y, 5) + 1;
			}
			else {
				highWin = winCount(x - 1, y, 1) + 1;
			}
		}
		if(stone[x][y - 1] == currentTurn) {		// 2��
			if(stone[x][y + 1] == currentTurn) {
				if(winCount(x, y - 1, 2) + winCount(x, y + 1, 6) + 1 > highWin)
					highWin = winCount(x, y - 1, 2) + winCount(x, y + 1, 6) + 1;
			}
			else {
				if(winCount(x, y - 1, 2) + 1 > highWin)
					highWin = winCount(x, y - 1, 2) + 1;
			}	
		}
		if(stone[x - 1][y - 1] == currentTurn) {	// 3��
			if(stone[x + 1][y + 1] == currentTurn) {
				if(winCount(x - 1, y - 1, 3) + winCount(x + 1, y + 1, 7) + 1 > highWin)
					highWin = winCount(x - 1, y - 1, 3) + winCount(x + 1, y + 1, 7) + 1;
			}
			else {
				if(winCount(x - 1, y - 1, 3) + 1 > highWin)
					highWin = winCount(x - 1, y - 1, 3) + 1;
			}	
		}
		if(stone[x - 1][y + 1] == currentTurn) {	// 4��
			if(stone[x + 1][y - 1] == currentTurn) {
				if(winCount(x - 1, y - 1, 3) + winCount(x + 1, y + 1, 7) + 1 > highWin)
					highWin = winCount(x - 1, y + 1, 4) + winCount(x + 1, y - 1, 8) + 1;
			}
			else {
				if(winCount(x - 1, y - 1, 3) + 1 > highWin)
					highWin = winCount(x - 1, y + 1, 4) + 1;
			}	
		}
		if(stone[x + 1][y] == currentTurn) {		// 5��
			if(stone[x - 1][y] == currentTurn) {
				if(winCount(x + 1, y, 5) + winCount(x - 1, y, 1) + 1 > highWin)
					highWin = winCount(x + 1, y, 5) + winCount(x - 1, y, 1) + 1;
			}
			else {
				if(winCount(x + 1, y, 5) + 1 > highWin)
					highWin = winCount(x + 1, y, 5) + 1;
			}	
		}
		if(stone[x][y + 1] == currentTurn) {		// 6��
			if(stone[x][y - 1] == currentTurn) {
				if(winCount(x, y + 1, 6) + winCount(x, y - 1, 2) + 1 > highWin)
					highWin = winCount(x, y + 1, 6) + winCount(x, y - 1, 2) + 1;
			}
			else {
				if(winCount(x, y + 1, 6) + 1 > highWin)
					highWin = winCount(x, y + 1, 6) + 1;
			}	
		}
		if(stone[x + 1][y + 1] == currentTurn) {	// 7��
			if(stone[x - 1][y - 1] == currentTurn) {
				if(winCount(x + 1, y + 1, 7) + winCount(x - 1, y - 1, 3) + 1 > highWin)
					highWin = winCount(x + 1, y + 1, 7) + winCount(x - 1, y - 1, 3) + 1;
			}
			else {
				if(winCount(x + 1, y + 1, 7) + 1 > highWin)
					highWin = winCount(x + 1, y + 1, 7) + 1;
			}	

		}
		if(stone[x + 1][y - 1] == currentTurn){		// 8��
			if(stone[x - 1][y + 1] == currentTurn) {
				if(winCount(x + 1, y - 1, 8) + winCount(x - 1, y + 1, 4) + 1 > highWin)
					highWin = winCount(x + 1, y - 1, 8) + winCount(x - 1, y + 1, 4) + 1;
			}
			else {
				if(winCount(x + 1, y - 1, 8) + 1 > highWin)
					highWin = winCount(x + 1, y - 1, 8) + 1;
			}	
		}
		return highWin;	
	}
	
	public int winCount(int x, int y, int direction) {
		if(direction == 1) {
			if(stone[x - 1][y] != currentTurn) return 1;
			else return winCount(x - 1, y, 1) + 1;
		}else if(direction == 2) {
			if(stone[x][y - 1] != currentTurn) return 1;
			else return winCount(x, y - 1, 2) + 1;
		}else if(direction == 3) {
			if(stone[x - 1][y - 1] != currentTurn) return 1;
			else return winCount(x - 1, y - 1, 3) + 1;
		}
		else if(direction == 4) {
			if(stone[x - 1][y + 1] != currentTurn) return 1;
			else return winCount(x - 1, y + 1, 4) + 1;
		}
		else if(direction == 5) {
			if(stone[x + 1][y] != currentTurn) return 1;
			else return winCount(x + 1, y, 5) + 1;
		}
		else if(direction == 6) {
			if(stone[x][y + 1] != currentTurn) return 1;
			else return winCount(x, y + 1, 6) + 1;
		}
		else if(direction == 7) {
			if(stone[x + 1][y + 1] != currentTurn) return 1;
			else return winCount(x + 1, y + 1, 7) + 1;
		}
		else if(direction == 8) {
			if(stone[x + 1][y - 1] != currentTurn) return 1;
			else return winCount(x + 1, y - 1, 8) + 1;
		}
		else return 300;
	}
	
	public void reset() {
		amount = 0;
		currentTurn = 0;
		
		for(int i = 0; i < 21; i++) {
			for(int j = 0; j < 21; j++) {
				stone[i][j] = -1;
			}
		}
		for(int i = 0; i < 21; i++) {
			stone[i][0] = 99;
			stone[0][i] = 99;
			stone[i][20] = 99;
			stone[20][i] = 99;
		}
	}
	
	public void resetGame() {
		amount = 0;
		currentTurn = 0;
		
		for(int i = 0; i < 21; i++) {
			for(int j = 0; j < 21; j++) {
				if(stone[i][j] == 0 || stone[i][j] == 1)
					stone[i][j] = -1;
			}
		}
	}
	
	public void show() {
		for(int i = 0; i < 21; i++) {
			for(int j = 0; j < 21; j++) {
				System.out.print(stone[i][j] + " ");
			}
			System.out.println();
		}
	}
	
	public void showNextMove() {
		for(int i = 0; i < 21; i++) {
			for(int j = 0; j < 21; j++) {
				System.out.print(all1[i][j] + " ");
			}
			System.out.println();
		}
		
		for(int i = 0; i < 21; i++) {
			for(int j = 0; j < 21; j++) {
				System.out.print(all2[i][j] + " ");
			}
			System.out.println();
		}
	}
	
	public double connect6ShapeScore(int consecutive, int openEnds, int currentTurn) {	// shape�� ���� ����ġ �ο�
		if (openEnds == 0 && consecutive < 6)
			return 0;
		switch (consecutive) {
			case 6:				// �� 6��
				return 200000;	// ���!
			case 5:				// �� 5��
				switch (openEnds) {
					case 1:		// ���� ���� ���� ���
						if (currentTurn == this.currentTurn)
							return 100000;
						return 50;
					case 2:		// ���� ���� ���� ���
						if (currentTurn == this.currentTurn)
							return 100000;
						return 5000;
				}
			case 4:				// �� 4��
				switch (openEnds) {
					case 1:		// ���� ���� ���� ���
						if (currentTurn == this.currentTurn)
							return 1000;
						return 5;
					case 2:		// ���� ���� ���� ���
						if (currentTurn == this.currentTurn)
							return 5000;
						return 200;
				}
			case 3:				// �� 3��
				switch (openEnds) {
					case 1:		// ���� ���� ���� ���
						if (currentTurn == this.currentTurn)
							return 7;
						return 5;
					case 2:		// ���� ���� ���� ���
						if (currentTurn == this.currentTurn)
							return 100;
						return 50;
				}
			case 2:				// �� 2��
				switch (openEnds) {
					case 1:		// ���� ���� ���� ���
						return 2;
					case 2:		// ���� ���� ���� ���
						return 5;
				}
			case 1:				// �� 1��
				switch (openEnds) {	
					case 1:		// ���� ���� ���� ���
						return 0.5;
					case 2:		// ���� ���� ���� ���
						return 1;
				}
			default:
				return 0;
		}
	}
	
	public double analyzeHorizontalSetsForBlack(int current_turn) {
		double score = 0;
		int countConsecutive = 0;
		int openEnds = 0;

		for (int i = 0; i < 21; i++) {
			for (int j = 0; j < 21; j++) {
				if (stone[j][i] == 0)									// ���� �������� �Ǹ� ������ 1����
					countConsecutive++;
				else if (stone[j][i] == -1 && countConsecutive > 0) {	// ���������� ���� ������ ������ ���
					if(countConsecutive == 2) {
						if(j + 4 < 21) {
							if(stone[j + 1][i] == 0 && stone[j + 2][i] == 0 && stone[j + 3][i] == 0 && stone[j + 3][i] != 0)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					else if(countConsecutive == 3) {
						if(j + 3 < 21) {
							if(stone[j + 1][i] == 0 && stone[j + 2][i] == 0 && stone[j + 3][i] != 0)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					else if(countConsecutive == 4) {
						if(j + 2 < 21) {
							if(stone[j + 1][i] == 0 && stone[j + 2][i] != 0)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					
					openEnds++;
					score += connect6ShapeScore(countConsecutive,
						openEnds, current_turn); 		// currentTurn is black
					countConsecutive = 0;
					openEnds = 1;
				}
				else if (stone[j][i] == -1)								// �� ���� �׳� ������ ���
					openEnds = 1;
				else if (countConsecutive > 0) {						// �������� �ٸ� ���� ������ ������ ���
					score += connect6ShapeScore(countConsecutive,
						openEnds, current_turn); 		// currentTurn is black
					countConsecutive = 0;
					openEnds = 0;
				}
				else openEnds = 0;										// �� ���� ���� ������ ������ ���
			}
			if (countConsecutive > 0)									// �������� ���� ������ ������ ���
				score += connect6ShapeScore(countConsecutive,
					openEnds, current_turn);			// currentTurn is black
			countConsecutive = 0;
			openEnds = 0;
		}
		return score;
	}
	
	public double analyzeVerticalSetsForBlack(int current_turn) {
		double score = 0;
		int countConsecutive = 0;
		int openEnds = 0;

		for (int i = 0; i < 21; i++) {
			for (int j = 0; j < 21; j++) {
				if (stone[i][j] == 0)									// ���� �������� �Ǹ� ������ 1����
					countConsecutive++;
				else if (stone[i][j] == -1 && countConsecutive > 0) {	// �������� �ٸ� ���� ������ ������ ���
					if(countConsecutive == 2) {
						if(j + 4 < 21) {
							if(stone[i][j + 1] == 0 && stone[i][j + 2] == 0 && stone[i][j + 3] == 0 && stone[i][j + 4] != 0)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					else if(countConsecutive == 3) {
						if(j + 3 < 21) {
							if(stone[i][j + 1] == 0 && stone[i][j + 2] == 0 && stone[i][j + 3] != 0)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					else if(countConsecutive == 4) {
						if(i + 2 < 21) {
							if(stone[i][j + 1] == 0 && stone[i][j + 2] != 0)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					
					openEnds++;
					score += connect6ShapeScore(countConsecutive,
						openEnds, 0); 		// currentTurn is black
					countConsecutive = 0;
					openEnds = 1;
				}
				else if (stone[i][j] == -1)								// �� ���� �׳� ������ ���
					openEnds = 1;
				else if (countConsecutive > 0) {						// �������� �ٸ� ���� ������ ������ ���
					score += connect6ShapeScore(countConsecutive,
						openEnds, 0); 		// currentTurn is black
					countConsecutive = 0;
					openEnds = 0;
				}
				else openEnds = 0;										// �� ���� ���� ������ ������ ���
			}
			if (countConsecutive > 0)									// �������� ���� ������ ������ ���
				score += connect6ShapeScore(countConsecutive,
					openEnds, 0);			// currentTurn is black
			countConsecutive = 0;
			openEnds = 0;
		}
		return score;
	}
	
	public double analyzeLeftDiagonalSetsForBlack(int current_turn) {
		double score = 0;
		int countConsecutive = 0;
		int openEnds = 0;
		int n = 21;	
		
		for(int i = 0; i <= 2 * n - 2; i++) {
			int lb, ub;
			if(21 <= i) lb = - (2 * n - 2 - i);
			else lb = - i;
			ub = -lb;
			
			for(int diff = lb; diff <= ub; diff += 2) {
				int x = (i + diff) >> 1;
				int y = i - x;
				
				if (stone[x][y] == 0)									// ���� �������� �Ǹ� ������ 1����
					countConsecutive++;
				else if (stone[x][y] == -1 && countConsecutive > 0) {	// �������� �ٸ� ���� ������ ������ ���
					
					if(countConsecutive == 2) {
						if(20 >= i && x + 4 < i) {
							if(stone[x + 1][y - 1] == 0 && stone[x + 2][y - 2] == 0 && stone[x + 3][y - 3] == 0 && stone[x + 4][y - 4] != 0)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
						else if(20 < i && y + 16 > i) {
							if(stone[x + 1][y - 1] == 0 && stone[x + 2][y - 2] == 0 && stone[x + 3][y - 3] == 0 && stone[x + 4][y - 4] != 0)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					else if(countConsecutive == 3) {
						if(20 >= i && x + 3 < i) {
							if(stone[x + 1][y - 1] == 0 && stone[x + 2][y - 2] == 0 && stone[x + 3][y - 3] != 0)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
						else if(20 < i && y + 17 > i) {
							if(stone[x + 1][y - 1] == 0 && stone[x + 2][y - 2] == 0 && stone[x + 3][y - 3] != 0)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					else if(countConsecutive == 4) {
						if(20 >= i && x + 2 < i) {
							if(stone[x + 1][y - 1] == 0 && stone[x + 2][y - 2] != 0)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
						else if(20 < i && y + 18 > i) {
							if(stone[x + 1][y - 1] == 0 && stone[x + 2][y - 2] != 0)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					
					openEnds++;
					score += connect6ShapeScore(countConsecutive,
						openEnds, 0); 		// currentTurn is black
					countConsecutive = 0;
					openEnds = 1;
				}
				else if (stone[x][y] == -1)								// �� ���� �׳� ������ ���
					openEnds = 1;
				else if (countConsecutive > 0) {						// �������� �ٸ� ���� ������ ������ ���
					score += connect6ShapeScore(countConsecutive,
						openEnds, 0); 		// currentTurn is black
					countConsecutive = 0;
					openEnds = 0;
				}
				else openEnds = 0;					
			}
			if (countConsecutive > 0)									// �������� ���� ������ ������ ���
				score += connect6ShapeScore(countConsecutive,
					openEnds, 0);			// currentTurn is black
			countConsecutive = 0;
			openEnds = 0;
		}
		return score;
	}
	
	public double analyzeRightDiagonalSetsForBlack(int current_turn) {
		double score = 0;
		int countConsecutive = 0;
		int openEnds = 0;
		int n = 21;
		
		for(int i = 0; i <= 2 * n - 2; i++) {
			int lb, ub;
			if(21 <= i) lb = - (2 * n - 2 - i);
			else lb = - i;
			ub = -lb;
			
			for(int diff = lb; diff <= ub; diff += 2) {
				int x = (i + diff) >> 1;
				int y = 20 - i + x;
				
				if (stone[x][y] == 0)									// ���� �������� �Ǹ� ������ 1����
					countConsecutive++;
				else if (stone[x][y] == -1 && countConsecutive > 0) {	// �������� �ٸ� ���� ������ ������ ���
					
					if(countConsecutive == 2) {
						if(20 >= i && x + 4 < i) {
							if(stone[x + 1][y + 1] == 0 && stone[x + 2][y + 2] == 0 && stone[x + 3][y + 3] == 0 && stone[x + 4][y + 4] != 0)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					else if(countConsecutive == 3) {
						if(20 >= i && x + 3 < i) {
							if(stone[x + 1][y - 1] == 0 && stone[x + 2][y - 2] == 0 && stone[x + 3][y - 3] != 0)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					else if(countConsecutive == 4) {
						if(20 >= i && x + 2 < i) {
							if(stone[x + 1][y - 1] == 0 && stone[x + 2][y - 2] != 0)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
						else if(20 < i && y + 18 > i) {
							if(stone[x + 1][y - 1] == 0 && stone[x + 2][y - 2] != 0)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					
					openEnds++;
					score += connect6ShapeScore(countConsecutive,
						openEnds, 0); 		// currentTurn is black
					countConsecutive = 0;
					openEnds = 1;
				}
				else if (stone[x][y] == -1)								// �� ���� �׳� ������ ���
					openEnds = 1;
				else if (countConsecutive > 0) {						// �������� �ٸ� ���� ������ ������ ���
					score += connect6ShapeScore(countConsecutive,
						openEnds, 0); 		// currentTurn is black
					countConsecutive = 0;
					openEnds = 0;
				}
				else openEnds = 0;					
			}
			if (countConsecutive > 0)									// �������� ���� ������ ������ ���
				score += connect6ShapeScore(countConsecutive,
					openEnds, 0);			// currentTurn is black
			countConsecutive = 0;
			openEnds = 0;
		}
		return score;
	}
	
	public double analyzeHorizontalSetsForWhite(int current_turn) {
		double score = 0;
		int countConsecutive = 0;
		int openEnds = 0;

		for (int i = 0; i < 21; i++) {
			for (int j = 0; j < 21; j++) {
				if (stone[j][i] == 1)									// ���� �������� �Ǹ� ������ 1����
					countConsecutive++;
				else if (stone[j][i] == -1 && countConsecutive > 0) {	// ���������� ���� ������ ������ ���
					if(countConsecutive == 2) {
						if(j + 4 < 21) {
							if(stone[j + 1][i] == 1 && stone[j + 2][i] == 1 && stone[j + 3][i] == 1 && stone[j + 3][i] != 1)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					else if(countConsecutive == 3) {
						if(j + 3 < 21) {
							if(stone[j + 1][i] == 1 && stone[j + 2][i] == 1 && stone[j + 3][i] != 1)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					else if(countConsecutive == 4) {
						if(j + 2 < 21) {
							if(stone[j + 1][i] == 1 && stone[j + 2][i] != 1)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					
					openEnds++;
					score += connect6ShapeScore(countConsecutive,
						openEnds, 1); 		// currentTurn is black
					countConsecutive = 0;
					openEnds = 1;
				}
				else if (stone[j][i] == -1)								// �� ���� �׳� ������ ���
					openEnds = 1;
				else if (countConsecutive > 0) {						// �������� �ٸ� ���� ������ ������ ���
					score += connect6ShapeScore(countConsecutive,
						openEnds, 1); 		// currentTurn is black
					countConsecutive = 0;
					openEnds = 0;
				}
				else openEnds = 0;										// �� ���� ���� ������ ������ ���
			}
			if (countConsecutive > 0)									// �������� ���� ������ ������ ���
				score += connect6ShapeScore(countConsecutive,
					openEnds, 1);			// currentTurn is black
			countConsecutive = 0;
			openEnds = 0;
		}
		return score;
	}
	
	public double analyzeVerticalSetsForWhite(int current_turn) {
		double score = 0;
		int countConsecutive = 0;
		int openEnds = 0;

		for (int i = 0; i < 21; i++) {
			for (int j = 0; j < 21; j++) {
				if (stone[i][j] == 1)									// ���� �������� �Ǹ� ������ 1����
					countConsecutive++;
				else if (stone[i][j] == -1 && countConsecutive > 0) {	// �������� �ٸ� ���� ������ ������ ���
					if(countConsecutive == 2) {
						if(j + 4 < 21) {
							if(stone[i][j + 1] == 1 && stone[i][j + 2] == 1 && stone[i][j + 3] == 1 && stone[i][j + 4] != 1)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					else if(countConsecutive == 3) {
						if(j + 3 < 21) {
							if(stone[i][j + 1] == 1 && stone[i][j + 2] == 1 && stone[i][j + 3] != 1)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					else if(countConsecutive == 4) {
						if(i + 2 < 21) {
							if(stone[i][j + 1] == 1 && stone[i][j + 2] != 1)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					
					openEnds++;
					score += connect6ShapeScore(countConsecutive,
						openEnds, 1); 		// currentTurn is black
					countConsecutive = 0;
					openEnds = 1;
				}
				else if (stone[i][j] == -1)								// �� ���� �׳� ������ ���
					openEnds = 1;
				else if (countConsecutive > 0) {						// �������� �ٸ� ���� ������ ������ ���
					score += connect6ShapeScore(countConsecutive,
						openEnds, 1); 		// currentTurn is black
					countConsecutive = 0;
					openEnds = 0;
				}
				else openEnds = 0;										// �� ���� ���� ������ ������ ���
			}
			if (countConsecutive > 0)									// �������� ���� ������ ������ ���
				score += connect6ShapeScore(countConsecutive,
					openEnds, 1);			// currentTurn is black
			countConsecutive = 0;
			openEnds = 0;
		}
		return score;
	}
	
	public double analyzeLeftDiagonalSetsForWhite(int current_turn) {
		double score = 0;
		int countConsecutive = 0;
		int openEnds = 0;
		int n = 21;
		
		for(int i = 0; i <= 2 * n - 2; i++) {
			int lb, ub;
			if(21 <= i) lb = - (2 * n - 2 - i);
			else lb = - i;
			ub = -lb;
			
			for(int diff = lb; diff <= ub; diff += 2) {
				int x = (i + diff) >> 1;
				int y = i - x;
				
				if (stone[x][y] == 1)									// ���� �������� �Ǹ� ������ 1����
					countConsecutive++;
				else if (stone[x][y] == -1 && countConsecutive > 0) {	// �������� �ٸ� ���� ������ ������ ���
					
					if(countConsecutive == 2) {
						if(20 >= i && x + 4 < i) {
							if(stone[x + 1][y - 1] == 1 && stone[x + 2][y - 2] == 1 && stone[x + 3][y - 3] == 1 && stone[x + 4][y - 4] != 1)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
						else if(20 < i && y + 16 > i) {
							if(stone[x + 1][y - 1] == 1 && stone[x + 2][y - 2] == 1 && stone[x + 3][y - 3] == 1 && stone[x + 4][y - 4] != 1)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					else if(countConsecutive == 3) {
						if(20 >= i && x + 3 < i) {
							if(stone[x + 1][y - 1] == 1 && stone[x + 2][y - 2] == 1 && stone[x + 3][y - 3] != 1)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
						else if(20 < i && y + 17 > i) {
							if(stone[x + 1][y - 1] == 1 && stone[x + 2][y - 2] == 1 && stone[x + 3][y - 3] != 1)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					else if(countConsecutive == 4) {
						if(20 >= i && x + 2 < i) {
							if(stone[x + 1][y - 1] == 1 && stone[x + 2][y - 2] != 1)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
						else if(20 < i && y + 18 > i) {
							if(stone[x + 1][y - 1] == 1 && stone[x + 2][y - 2] != 1)
								score += connect6ShapeScore(5,
										openEnds, current_turn); 		// currentTurn is black
						}
					}
					
					openEnds++;
					score += connect6ShapeScore(countConsecutive,
						openEnds, 1); 		// currentTurn is black
					countConsecutive = 0;
					openEnds = 1;
				}
				else if (stone[x][y] == -1)								// �� ���� �׳� ������ ���
					openEnds = 1;
				else if (countConsecutive > 0) {						// �������� �ٸ� ���� ������ ������ ���
					score += connect6ShapeScore(countConsecutive,
						openEnds, 1); 		// currentTurn is black
					countConsecutive = 0;
					openEnds = 0;
				}
				else openEnds = 0;					
			}
			if (countConsecutive > 0)									// �������� ���� ������ ������ ���
				score += connect6ShapeScore(countConsecutive,
					openEnds, 1);			// currentTurn is black
			countConsecutive = 0;
			openEnds = 0;
		}
		return score;
	}
	
	public double analyzeRightDiagonalSetsForWhite(int current_turn) {
		double score = 0;
		int countConsecutive = 0;
		int openEnds = 0;
		int n = 21;
		
		for(int i = 0; i <= 2 * n - 2; i++) {
			int lb, ub;
			if(21 <= i) lb = - (2 * n - 2 - i);
			else lb = - i;
			ub = -lb;
			
			for(int diff = lb; diff <= ub; diff += 2) {
				int x = (i + diff) >> 1;
				int y = 20 - i + x;
				
				if (stone[y][x] == 1)									// ���� �������� �Ǹ� ������ 1����
					countConsecutive++;
				else if (stone[y][x] == -1 && countConsecutive > 0) {	// �������� �ٸ� ���� ������ ������ ���
					openEnds++;
					score += connect6ShapeScore(countConsecutive,
						openEnds, 1); 		// currentTurn is black
					countConsecutive = 0;
					openEnds = 1;
				}
				else if (stone[y][x] == -1)								// �� ���� �׳� ������ ���
					openEnds = 1;
				else if (countConsecutive > 0) {						// �������� �ٸ� ���� ������ ������ ���
					score += connect6ShapeScore(countConsecutive,
						openEnds, 1); 		// currentTurn is black
					countConsecutive = 0;
					openEnds = 0;
				}
				else openEnds = 0;					
			}
			if (countConsecutive > 0)									// �������� ���� ������ ������ ���
				score += connect6ShapeScore(countConsecutive,
					openEnds, 1);			// currentTurn is black
			countConsecutive = 0;
			openEnds = 0;
		}
		return score;
	}
	
	public void findOptimal() {
		
		amount++;
		
		for(int i = 1; i < 20; i++) {
			for(int j = 1; j < 20; j++) {
				nextStone[i][j] = stone[i][j];
			}
		}
		

		if(findConnect6Move()) {
			System.out.println("���� 6�� ��ģ ��");
			return;
		}
		else if(findDefenceMove()) {
			System.out.println("���� ��� ��ģ ��");
			return;
		}
		else if(findAttackMove()) {
			System.out.println("���� ���� ��ģ ��");
			return;
		}

		
	}
	
	public boolean findConnect6Move() {
		if(isFirst) {
			for(int i = 1; i < 20; i++) {
				for(int j = 1; j < 20; j++) {
					if(stone[i][j] != -1) {			// ���̸�
						all2[i][j] = -999;
					}
					else if(stone[i][j] == -1) {	// ��ĭ�̸�
						stone[i][j] = 1;
						
						hor2[i][j] = analyzeHorizontalSetsForWhite(currentTurn);
						ver2[i][j] = analyzeVerticalSetsForWhite(currentTurn);
						left2[i][j] = analyzeLeftDiagonalSetsForWhite(currentTurn);
						right2[i][j] = analyzeRightDiagonalSetsForWhite(currentTurn);
						all2[i][j] = hor2[i][j] + ver2[i][j] + left2[i][j] + right2[i][j];
						
						stone[i][j] = -1;
					}
					
				}
			}
			
			double max = 0.0;
			int maxX = 0;
			int maxY = 0;
			
			for(int i = 1; i < 20; i++) {
				for(int j = 1; j < 20; j++) {
					if(all2[i][j] > 5000 && all2[i][j] > max) {
						max = all2[i][j];
						maxX = i;
						maxY = j;
					}
				} 
			}
			
			System.out.println(maxX + " asdf " + maxY);
			if(maxX != 0 && maxY != 0) {
				nextX = maxX - 1;
				nextY = maxY - 1;
				System.out.println(nextX + " / " + nextY);
				stone[maxX][maxY] = 1;
				return true;
			}
			
		}
		else {
			for(int i = 1; i < 20; i++) {
				for(int j = 1; j < 20; j++) {
					if(stone[i][j] != -1) {
						all1[i][j] = -999;
					}
					else if(stone[i][j] == -1) {
						stone[i][j] = 0;
						
						hor1[i][j] = analyzeHorizontalSetsForBlack(currentTurn);
						ver1[i][j] = analyzeVerticalSetsForBlack(currentTurn);
						left1[i][j] = analyzeLeftDiagonalSetsForBlack(currentTurn);
						right1[i][j] = analyzeRightDiagonalSetsForBlack(currentTurn);
						all1[i][j] = hor1[i][j] + ver1[i][j] + left1[i][j] + right1[i][j];
						
						stone[i][j] = -1;
					}
					
				}
			}
			
			double max = 0.0;
			int maxX = 0;
			int maxY = 0;
			
			for(int i = 1; i < 20; i++) {
				for(int j = 1; j < 20; j++) {
					if(all1[i][j] > 5000 && all1[i][j] > max) {
						max = all1[i][j];
						maxX = i;
						maxY = j;
					}
				} 
			}
			
			if(maxX != 0 && maxY != 0) {
				nextX = maxX - 1;
				nextY = maxY - 1;
				System.out.println(nextX + " / " + nextY);
				stone[maxX][maxY] = 0;
				return true;
			}
		}
		return false;
	}
	
	public boolean findDefenceMove() {
		if(isFirst) {
			for(int i = 1; i < 20; i++) {
				for(int j = 1; j < 20; j++) {
					if(stone[i][j] != -1) {
						all1[i][j] = -999;
					}
					else if(stone[i][j] == -1) {
						stone[i][j] = 0;
						
						hor1[i][j] = analyzeHorizontalSetsForBlack(currentTurn);
						ver1[i][j] = analyzeVerticalSetsForBlack(currentTurn);
						left1[i][j] = analyzeLeftDiagonalSetsForBlack(currentTurn);
						right1[i][j] = analyzeRightDiagonalSetsForBlack(currentTurn);
						all1[i][j] = hor1[i][j] + ver1[i][j] + left1[i][j] + right1[i][j];
						
						stone[i][j] = -1;
					}
				}
			}
			
			double max = all1[0][0];
			int maxX = 0;
			int maxY = 0;
			
			for(int i = 1; i < 20; i++) {
				for(int j = 1; j < 20; j++) {
					if(all1[i][j] > max) {
						max = all1[i][j];
						maxX = i;
						maxY = j;
					}
				}
			}
			
			System.out.println(maxX + " / " + maxY);
			if(amount <= 3) {
				nextX = maxX - 1;
				nextY = maxY - 1;
				stone[maxX][maxY] = 1;
				return true;
			}
			else if(max > 1200) {
				nextX = maxX - 1;
				nextY = maxY - 1;
				stone[maxX][maxY] = 1;
				return true;
			}
			else {
				return false;
			}
			
		}
		else {
			for(int i = 1; i < 20; i++) {
				for(int j = 1; j < 20; j++) {
					if(stone[i][j] != -1) {
						all2[i][j] = -999;
					}
					else if(stone[i][j] == -1) {
						stone[i][j] = 1;
						
						hor2[i][j] = analyzeHorizontalSetsForWhite(1);
						ver2[i][j] = analyzeVerticalSetsForWhite(1);
						left2[i][j] = analyzeLeftDiagonalSetsForWhite(1);
						right2[i][j] = analyzeRightDiagonalSetsForWhite(1);
						all2[i][j] = hor2[i][j] + ver2[i][j] + left2[i][j] + right2[i][j];
						
						stone[i][j] = -1;
					}
				}
			}
			
			double max = all2[0][0];
			int maxX = 0;
			int maxY = 0;
			
			for(int i = 1; i < 20; i++) {
				for(int j = 1; j < 20; j++) {
					if(all2[i][j] > max) {
						max = all2[i][j];
						maxX = i;
						maxY = j;
					}
				}
			}
			
			System.out.println(maxX + " / " + maxY);
			if(max > 1200) {
				nextX = maxX - 1;
				nextY = maxY - 1;
				stone[maxX][maxY] = 1;
				return true;
			}
			else {
				return false;
			}
		}
	}
	
	public boolean findAttackMove() {	
		
		if(isFirst) {
			double max = 0;
			int maxX = 0;
			int maxY = 0;
			
			for(int i = 1; i < 20; i++) {
				for(int j = 1; j < 20; j++) {
					if(all2[i][j] > max) {
						max = all2[i][j];
						maxX = i;
						maxY = j;
					}
				}
			}
			
			System.out.println(maxX + " / " + maxY);
			nextX = maxX - 1;
			nextY = maxY - 1;
			stone[maxX][maxY] = 1;
			return true;

		}
		else {
			
			double max = 0;
			int maxX = 0;
			int maxY = 0;
			
			for(int i = 1; i < 20; i++) {
				for(int j = 1; j < 20; j++) {
					if(all1[i][j] > max) {
						max = all1[i][j];
						maxX = i;
						maxY = j;
					}
				}
			}
			
			System.out.println(maxX + " / " + maxY);
			nextX = maxX - 1;
			nextY = maxY - 1;
			stone[maxX][maxY] = 0;
			return true;

		}
		
	}
}
